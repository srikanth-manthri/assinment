// Assignment operators:
let x = 5;

x = x + 5;
console.log(x);

let y = 6;
y += 5;
console.log(y);

let z = 6;
z *= 7;
console.log(z);
