// Arthematic operations:

// Defining variables:
let x = 2;
let y = 3;

// addition
console.log(x + y);
// substraction
console.log(x - y);
// multiplication
console.log(x * y);
// division
console.log(x / y);
// Exponentation
console.log(x ** y);
// mode
console.log(x % y);
// increament
console.log(x++);
console.log(x);
// Decreament
console.log(--x);

