// If point is greater than 100, then customer is a gold or a silver 

// Condition 01
let point = 110;
let type = point > 100 ? 'Gold' : 'Silver';
console.log(type);

// Condition 02
let customer = 90;
let result = customer > 100 ? 'Gold' : 'Silver';
console.log(result);