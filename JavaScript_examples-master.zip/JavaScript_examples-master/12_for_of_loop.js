// Example 03: Array for of loop
// Where we just what to iterate elements in a array.
// Note:
// colors: is an array.
// color: is an element in colors array 

const colors = ['red', 'gree', 'blue'];

for (let color of colors) {
    console.log("value", color);
};